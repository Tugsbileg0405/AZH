<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rule extends Model
{
    //
}
