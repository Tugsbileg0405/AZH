<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <div class="section section-newspage">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <?php if($allnews->isEmpty()): ?>
                                <div class="content">
                                <p class="text-gray">Мэдээлэл байхгүй байна.</p>
                                </div>
                            <?php else: ?>
                            <?php $__currentLoopData = $allnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card card-blog card-plain card-allnews">
                                <h6 class="card-date"><?php echo e($news->created_at->format('Y оны m сарын d өдөр')); ?></h6>
                                <a class="header" href="<?php echo e(url('news', $news->id)); ?>">
                                    <img src="<?php echo e(asset($news->image)); ?>" class="image-header">
                                </a>
                                <div class="content">
                                    <a class="card-title" href="<?php echo e(url('news', $news->id)); ?>">
                                        <h3><?php echo e($news->title); ?></h3>
                                    </a>
                                    <p class="text-gray"><?php echo $news->short_description; ?></p>
                                </div>
                                <a class="btn btn-gray" href="<?php echo e(url('news', $news->id)); ?>">Дэлгэрэнгүй унших
                                    <i class="fa fa-chevron-right"></i>
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <nav>
                                <div class="text-center">
                                    <?php echo e($allnews->links()); ?>

                                </div>
                            </nav>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-offset-1 text-center">
                     <?php if(!$categories->isEmpty()): ?>
                    <div class="title-area">
                        <h2 class="description">Ангилал</h2>
                    </div>
                    <div class="list-group" id="newsSidebar">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('category', $category->id)); ?>" class="list-group-item <?php echo e(Request::is('category', $category->id) ? 'active' : ''); ?>">
                            <?php echo e($category->name); ?>

                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>