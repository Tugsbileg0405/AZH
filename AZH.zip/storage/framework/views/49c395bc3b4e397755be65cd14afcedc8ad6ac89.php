<html>

<head>
    <style>
        .column {
            float: left;
            width: 50%;
        }
    </style>
</head>

<body>
    <div class="column">
        <?php echo e($email); ?> хэрэглэгч манай веб хуудсыг дагасанд баярлалаа.       
    </div>
</body>

</html>