<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <div class="section section-program">
        <div class="container">
            <div class="row">
                 <div class="section section-our-projects">
                         <div class="title-area">
                             <h2><?php echo e($programName->name); ?></h2>
                             <div class="separator separator-danger">♦</div>
                             <p class="description">
                                 <?php echo e($programName->description); ?>

                             </p>
                         </div>
                         <?php if($programName->programs): ?>
                         <div class="container">
                             <div class="row">
                                 <?php $__currentLoopData = $programName->programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <div class="col-md-6">
                                     <div class="project">
                                         <img src="<?php echo e(asset($program->image)); ?>">
                                         <a class="over-area" href="<?php echo e(url('program', $program->id)); ?>">
                                             <div class="content">
                                                 <h2><?php echo e($program->title); ?></h2>
                                                 <p><?php echo e($program->short_description); ?></p>
                                             </div>
                                         </a>
                                     </div>
                                 </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </div>
                         </div>
                         <?php endif; ?>
                  </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>