<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
              <div class="card">
                    <div class="header">
                        <h4 class="title">Засах</h4>
                    </div>
                    <div class="content">
                       <form method="POST" id="myform" action="<?php echo e(url('/admin/sectorinfo/edit',$sectorInfo->id)); ?>">
                                   <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Гарчиг:</label>
                                                <input type="text" value="<?php echo e($sectorInfo->title); ?>" required class="form-control border-input" name='title' placeholder="Гарчиг">
                                            </div>
                                        </div>
                                    </div>

 
                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Тайлбар:</label>
                                                <textarea class="form-control my-editor" name='description' required placeholder="Тайлбар" rows="3"><?php echo e($sectorInfo->description); ?></textarea>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Салбарын байрлал:</label>
                                                <select class="form-control" required name="location">
                                                    <option value="">Cалбараас сонгоно уу</option>
                                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($location->id); ?>" <?php echo e($sectorInfo->location_id == $location->id ? 'selected' : ''); ?>><?php echo e($location->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Нэмэх</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
	<script type="text/javascript">
        $('#lfm').filemanager('image');
    	$(document).ready(function(){
            <?php if(session('status')): ?>
        	$.notify({
            	icon: 'ti-check',
            	message: " <?php echo e(session('status')); ?>"

            },{
                type: 'success',
                timer: 2000
            });
           <?php endif; ?>
    	});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>