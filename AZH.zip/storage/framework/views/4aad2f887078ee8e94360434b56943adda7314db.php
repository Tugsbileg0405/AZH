<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <div class="section section-newspage">
        <div class="container">
            <div class="row">
                    <div class="section section-faq">
                        <div class="container">
                            <div class="header-faq text-center">
                                <h2>Хөтөлбөрүүд</h2>
                                <div class="separator separator-danger">✻</div>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = $programNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $programName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-6">
                                    <div class="box">
                                        <a href="<?php echo e(url('programs', $programName->id)); ?>">
                                        <h3 class="title-description"><?php echo e($index + 1); ?>. <?php echo e($programName->name); ?></h3>
                                        </a>
                                        <p class="text-description text-gray"><?php echo e($programName->description); ?></p>
                                         <a class="btn btn-gray" href="<?php echo e(url('programs', $programName->id)); ?>">Дэлгэрэнгүй унших
                                            <i class="fa fa-chevron-right"></i>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>