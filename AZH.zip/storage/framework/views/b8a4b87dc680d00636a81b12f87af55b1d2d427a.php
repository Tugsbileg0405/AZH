<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <div class="section section-about">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <ul class="nav nav-text nav-about" id="myTab" role="tablist">
                                <li class="nav-item active">
                                    <a class="nav-link" data-toggle="tab" href="#home" role="tab" aria-controls="home">Танилцуулга</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#history" role="tab" aria-controls="profile">Түүх</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#rule" role="tab" aria-controls="messages">Дүрэм</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#structure" role="tab" aria-controls="settings">Бүтэц</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#location" role="tab" aria-controls="settings">Салбарууд</a>
                                </li>
                            </ul>

                            <div class="tab-content about-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="row">
                                        <div class="col-md-12">
                                                <?php if(!$intro->isEmpty()): ?>
                                                <?php echo $intro[0]->description; ?>

                                                <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="history" role="tabpanel">
                                    <div class="panel-group timeline" id="experience">
                                        <?php if(!$vow->isEmpty()): ?>
                                            <?php echo $vow[0]->description; ?>

                                        <?php endif; ?>
                                        <?php if(!$histories->isEmpty()): ?>
                                        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="timeline-item">
                                            <div class="timeline-year">
                                                <h2 class="timeline-year"><?php echo e($history->date); ?></h2>
                                            </div>

                                            <div class="timeline-btn">
                                            </div>

                                            <div class="panel">
                                                <div class="panel-heading">
                                                    <div class="panel-title">
                                                        <a href="#exp<?php echo e($history->id); ?>" data-toggle="collapse" data-parent="#experience">
                                                            <h4><?php echo e($history->title); ?></h4>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div id="exp<?php echo e($history->id); ?>" class="panel-collapse collapse <?php if($index == 0): ?> <?php echo e('in'); ?> <?php endif; ?>">
                                                    <div class="panel-body">
                                                        <div class="demo-gallery">
                                                            <ul id="lightgallery<?php echo e($index); ?>" class="list-unstyled row">
                                                                <?php if($history->images): ?>
                                                                    <?php $__currentLoopData = unserialize($history->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li class="col-xs-6 col-sm-4 col-md-4" data-src="<?php echo e(asset($image)); ?>" data-sub-html="<h4><?php echo e($history->title); ?></h4><p><?php echo e($history->description); ?></p>">
                                                                        <a href="">
                                                                            <img class="img-responsive" src="<?php echo e(asset($image)); ?>">
                                                                        </a>
                                                                    </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                               <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                        <p>
                                                           <?php echo e($history->description); ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="rule" role="tabpanel">
                                    <h2 class="rule-header">
                                        <?php if(!$rule->isEmpty()): ?>
                                        <?php echo e($rule[0]->title); ?>

                                        <?php endif; ?>
                                    </h2>
                                    <h2 class="rule-description">
                                        <?php if(!$rule->isEmpty()): ?>
                                            <?php echo e($rule[0]->subtitle); ?>

                                        <?php endif; ?>
                                    </h2>
                                    <div class="btn-group">
                                        <button class="btn">
                                            <i class="fa fa-download"></i>
                                            ТАТАЖ АВАХ
                                        </button>
                                        <button class="btn" onclick="printDiv('rule')">
                                            <i class="fa fa-print"></i> ХЭВЛЭХ
                                        </button>
                                    </div>
                                    <div class="rules">
                                        <?php if(!$rule->isEmpty()): ?>
                                           <?php echo $rule[0]->description; ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="structure" role="tabpanel">
                                     <div class="row">
                                        <div class="col-md-12">
                                                <?php if(!$structure->isEmpty()): ?>
                                                  <?php echo $structure[0]->description; ?>

                                                <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane " id="location" role="tabpanel">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <p>
                                                Аймаг эсвэл дүүрэг сонгох:
                                            </p>
                                            <select class="form-control" id="aimag">
                                                <option value="">Cалбараас сонгоно уу</option>
                                                <?php $__currentLoopData = $sectionInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectionInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($sectionInfo->location_id); ?>"><?php echo e($sectionInfo->province->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="location-content">
                                        <h2 class="rule-header"></h2>
                                        <p class="description">
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-md-offset-1 text-center">
                    <div class="title-area">
                        <h2 class="description">Мэдээ мэдээлэл</h2>
                    </div>
                    <div class="news-card">

                    </div>
                </div>
            </div>
        </div>
    </div>
<input type="text" hidden id="number" value="<?php echo e($histories->count()); ?>">
<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function printDiv(divName) {
             var printContents = document.getElementById(divName).innerHTML;
             var originalContents = document.body.innerHTML;
             document.body.innerHTML = printContents;
             window.print();
             document.body.innerHTML = originalContents;
       }
        var length = $('#number').val();
        var i = 0; 
        for(i; i< length;i++){
            var number = i;
           $('#lightgallery'+ number).lightGallery();
        }


         $('#aimag').change(function() {
             $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
            });
             $.get("<?php echo e(url('sector')); ?>"+ "/" + $(this).val(), function( data ) {
                $('.location-content .rule-header').html(data[0].title);
                $('.location-content .description').html(data[0].description);
            });
            $.get("<?php echo e(url('sectornews')); ?>"+ "/" + $(this).val(), function( data ) {
                $('.news-card').empty();
                data.forEach(function(news){
                    var date = new Date(news.created_at);
                   $( ".news-card" ).append( '<div class="card card-blog card-plain animated bounceInUp ">\
                        <a href="<?php echo e(url("news")); ?>/'+news.id+'" class="header">\
                            <h6 class="card-date">'+  date.getFullYear() + ' оны '  + (date.getMonth() + 1) + ' сарын ' + date.getDate() + ' өдөр' +'</h6>\
                            <img src="<?php echo e(asset('')); ?>' + news.image +'" class="image-header">\
                        </a>\
                        <div class="content">\
                            <a href="<?php echo e(url("news")); ?>/'+news.id+'" class="card-title">\
                                <h3>'+news.title+'</h3>\
                            </a>\
                            <div class="line-divider line-danger"></div>\
                        </div>\
                    </div>' );
                })
            });
        });
        $($('#aimag').children()[1]).prop('selected', 'selected').change();

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>