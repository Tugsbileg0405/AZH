 <?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="header">
                    <h4 class="title">Мэдээлэл</h4>
                </div>
                <div class="content">
                    <div class="row">
                        <form method="POST"  action="<?php echo e(url('/admin/options', 1)); ?>">
                            <div class="col-lg-4 col-sm-6">
                                <div class="card">
                                    <div class="content">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Нэр</label>
                                                            <input type="text" class="form-control border-input" required name='name' value="<?php echo e($sectors->name); ?>" placeholder="Нэр">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Тайлбар</label>
                                                            <input type="text" class="form-control border-input" required name='value' value="<?php echo e($sectors->value); ?>" placeholder="Тайлбар">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <hr>
                                        <button class="btn btn-info btn-fill btn-sm" type="submit">
                                             Хадгалах
                                         </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <form method="POST"  action="<?php echo e(url('/admin/options', 2)); ?>">
                            <div class="col-lg-4 col-sm-6">
                                <div class="card">
                                    <div class="content">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Нэр</label>
                                                            <input type="text" class="form-control border-input" required name='name' value="<?php echo e($members->name); ?>" placeholder="Нэр">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Тайлбар</label>
                                                            <input type="text" class="form-control border-input" required name='value' value="<?php echo e($members->value); ?>" placeholder="Тайлбар">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <hr>
                                        <button class="btn btn-info btn-fill btn-sm" type="submit">
                                             Хадгалах
                                         </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <form method="POST"  action="<?php echo e(url('/admin/options', 3)); ?>">
                            <div class="col-lg-4 col-sm-6">
                                <div class="card">
                                    <div class="content">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Нэр</label>
                                                            <input type="text" class="form-control border-input" required name='name' value="<?php echo e($projects->name); ?>" placeholder="Нэр">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Тайлбар</label>
                                                            <input type="text" class="form-control border-input" required name='value' value="<?php echo e($projects->value); ?>" placeholder="Тайлбар">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <hr>
                                        <button class="btn btn-info btn-fill btn-sm" type="submit">
                                             Хадгалах
                                         </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?> <?php $__env->startPush('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
          
        <?php if(session('optionstatus')): ?>
        $.notify({
            icon: 'fa fa-check',
            message: " <?php echo e(session('optionstatus')); ?>"

        }, {
            type: 'success',
            timer: 1000
        });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>