<?php $file_name = $file['name'];?>
<?php $thumb_src = $file['thumb'];?>

<div class="thumbnail clickable" onclick="useFile('<?php echo e($file_name); ?>')">
  <div class="square" id="<?php echo e($file_name); ?>" data-url="<?php echo e($file['url']); ?>">
    <?php if($thumb_src): ?>
    <img src="<?php echo e($thumb_src); ?>">
    <?php else: ?>
    <div class="icon-container">
      <i class="fa <?php echo e($file['icon']); ?> fa-5x"></i>
    </div>
    <?php endif; ?>
  </div>
</div>

<div class="caption text-center">
  <div class="btn-group">
    <button type="button" onclick="useFile('<?php echo e($file_name); ?>')" class="btn btn-default btn-xs">
      <?php echo e(str_limit($file_name, $limit = 10, $end = '...')); ?>

    </button>
    <button type="button" class="btn btn-default dropdown-toggle btn-xs" data-toggle="dropdown" aria-expanded="false">
      <span class="caret"></span>
      <span class="sr-only">Toggle Dropdown</span>
    </button>
    <ul class="dropdown-menu" role="menu">
      <li><a href="javascript:rename('<?php echo e($file_name); ?>')"><i class="fa fa-edit fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-rename')); ?></a></li>
      <li><a href="javascript:download('<?php echo e($file_name); ?>')"><i class="fa fa-download fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-download')); ?></a></li>
      <li class="divider"></li>
      <?php if($thumb_src): ?>
      <li><a href="javascript:fileView('<?php echo e($file_name); ?>', '<?php echo e($file["updated"]); ?>')"><i class="fa fa-image fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-view')); ?></a></li>
      <li><a href="javascript:resizeImage('<?php echo e($file_name); ?>')"><i class="fa fa-arrows fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-resize')); ?></a></li>
      <li><a href="javascript:cropImage('<?php echo e($file_name); ?>')"><i class="fa fa-crop fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-crop')); ?></a></li>
      <li class="divider"></li>
      <?php endif; ?>
      <li><a href="javascript:trash('<?php echo e($file_name); ?>')"><i class="fa fa-trash fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-delete')); ?></a></li>
    </ul>
  </div>
</div>
