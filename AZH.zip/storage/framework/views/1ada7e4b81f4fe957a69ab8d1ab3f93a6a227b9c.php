<div class="photo">
	<img src="<?php echo e(asset($photo)); ?>">
	<input type="hidden" name="photos[]" value="<?php echo e($photo); ?>">
	<i class="fa fa-close fa-4x" aria-hidden="true"></i>
    <div class="wait">
        <div class="loader"></div>
    </div>
</div>