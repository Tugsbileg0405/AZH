<?php $folder_name = $directory->name; ?>
<?php $folder_path = $directory->path; ?>

<div class="thumbnail clickable">
  <div data-id="<?php echo e($folder_path); ?>" class="folder-item square">
    <img src="<?php echo e(asset('vendor/laravel-filemanager/img/folder.png')); ?>">
  </div>
</div>

<div class="caption text-center">
  <div class="btn-group">
    <button type="button" data-id="<?php echo e($folder_path); ?>" class="btn btn-default btn-xs folder-item">
      <?php echo e(str_limit($folder_name, $limit = 10, $end = '...')); ?>

    </button>
    <button type="button" class="btn btn-default dropdown-toggle btn-xs" data-toggle="dropdown" aria-expanded="false">
      <span class="caret"></span>
      <span class="sr-only">Toggle Dropdown</span>
    </button>
    <ul class="dropdown-menu" role="menu">
      <li><a href="javascript:rename('<?php echo e($folder_name); ?>')"><i class="fa fa-edit fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-rename')); ?></a></li>
      <li><a href="javascript:trash('<?php echo e($folder_name); ?>')"><i class="fa fa-trash fa-fw"></i> <?php echo e(Lang::get('laravel-filemanager::lfm.menu-delete')); ?></a></li>
    </ul>
  </div>
</div>
