 <?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="section section-aprogram">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row">
                  <div class="col-md-10 col-md-offset-1">
                         <div class="section-white">
                            <div class="title">
                                <h2><?php echo e($program->title); ?></h2>
                                <div class="separator separator-danger">♦</div>
                            </div>
                            <img class="img-responsive" src="<?php echo e(asset($program->image)); ?>">
                                <?php echo $program->description; ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php $programs = app('App\Program'); ?>
            <div class="col-md-3 col-md-offset-1">
                <div class="title-area">
                    <h2 class="description">Холбоотой хөтөлбөрүүд</h2>
                </div>
                <?php $__currentLoopData = $programs->where('programName_id',$program->programName_id)->where('id', '!=', $program->id)->orderBy('created_at', 'desc')->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherprogram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-blog card-plain card-side card-side">
                    <a href="<?php echo e(url('program', $otherprogram->id)); ?>" class="header">
                                <img src="<?php echo e(asset($otherprogram->image)); ?>" class="image-header">
                            </a>
                    <div class="content">
                        <a href="<?php echo e(url('program', $otherprogram->id)); ?>" class="card-title">
                            <h3><?php echo e($otherprogram->title); ?></h3>
                        </a>
                        <div class="line-divider line-danger"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>