<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <div class="section section-program">
        <div class="container">
            <div class="row">
                <div class="section section-our-projects">
                     <div class="title-area">
                             <h2><?php echo e($program->title); ?></h2>
                             <div class="separator separator-danger">♦</div>
                             
                     </div>
                      <div class="container">
                         <div class="row">
                             <div class="col-md-12">
                                 <img class="img-responsive" src="<?php echo e(asset($program->image)); ?>">
                                  <p class="description">
                                      <?php echo $program->description; ?>

                                  </p>
                             </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>