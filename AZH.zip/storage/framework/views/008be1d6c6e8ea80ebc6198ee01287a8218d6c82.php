<div class="row">

  <?php if((sizeof($files) > 0) || (sizeof($directories) > 0)): ?>

  <?php $__currentLoopData = $directories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $directory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-4 col-md-3 col-lg-2 img-row">
    <?php echo $__env->make('laravel-filemanager::folders', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-sm-4 col-md-3 col-lg-2 img-row">
    <?php echo $__env->make('laravel-filemanager::item', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php else: ?>
  <div class="col-md-12">
    <p><?php echo e(Lang::get('laravel-filemanager::lfm.message-empty')); ?></p>
  </div>
  <?php endif; ?>

</div>
