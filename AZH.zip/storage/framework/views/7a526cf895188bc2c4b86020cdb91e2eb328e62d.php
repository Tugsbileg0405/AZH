<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


 <div class="section section-login">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                    <div class="panel-heading">
                        <h3>
                            Нэвтрэх
                        </h3>
                    </div>
                    <div class="panel-body" style="border:none">
                        <form class="form-group" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email">Таны цахим шуудан</label>
                                <input id="email" type="email" class="form-control" placeholder="Цахим шуудангийн хаягаа оруулана уу" name="email" value="<?php echo e(old('email')); ?>" required autofocus> <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                         <strong><?php echo e($errors->first('email')); ?></strong>
                                     </span> <?php endif; ?>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password">Таны нууц үг</label>
                                <input id="password" type="password" placeholder="Цахим шуудангийн хаягаа оруулана уу" class="form-control" name="password" required <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span> <?php endif; ?>
                            </div>

                            <!--<div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>-->

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6" style="line-height:40px">
                                        <a href="<?php echo e(route('password.request')); ?>">
                                            Нууц үгээ мартсан?
                                        </a>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6" style="text-align:right">
                                        <button type="submit" class="btn btn-primary">
                                            Нэвтрэх
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>