<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('img/apple-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('img/favicon.png')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link href="<?php echo e(asset('css/gaia.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrapValidator.min.css')); ?>" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet ' type='text/css '>
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/fonts/pe-icon-7-stroke.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightslider.css' )); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightGallery.css' )); ?>">
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
    <div id="app">
       
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?> " type="text/javascript "></script>
    <script src="<?php echo e(asset('js/bootstrap.js ')); ?>" type="text/javascript "></script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?> "></script>
    <script src="<?php echo e(asset('js/lightgallery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrapValidator.min.js')); ?>"></script>
    <!--  js library for devices recognition -->
    <script type="text/javascript " src="<?php echo e(asset('js/modernizr.js')); ?> "></script>
    <!--  script for google maps   -->
     <script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAChBN0MVMVMizgvWhVZBFZ3afH4xWNGhQ">
    </script>
    <script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>
    <!--   file where we handle all the script from the Gaia - Bootstrap Template   -->
    <script type="text/javascript " src="<?php echo e(asset('js/gaia.js')); ?> "></script>
    <script type="text/javascript " src="<?php echo e(asset('js/custom.js ')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>

