 <div class="sidebar" data-background-color="white" data-active-color="danger">

     	<div class="sidebar-wrapper" >
            <div class="logo">
                <a href="" class="simple-text">
                    АЗХ админ
                </a>
            </div>
           <div id="treeview2" class="sidebar-wrapper"></div>
    	</div>
</div>

    <?php $__env->startPush('script'); ?>
    <script>
         var defaultData = [
            {
            text: 'Нүүр',
            selectable: false,
            state: {
                expanded: <?php echo e(Request::is('admin/options*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/president*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/presidents*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/sendmail*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/slide*') ? 'true' : 'false'); ?>,
            },
            nodes: [
                {
                text: 'Слайд',
                icon: 'fa fa-sliders',
                state: {
                        selected:<?php echo e(Request::is('admin/slide*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/slide')); ?>",
                tags: ['0']
              },
              {
                text: 'Мэдээлэл',
                icon: 'fa fa-info',
                state: {
                        selected:<?php echo e(Request::is('admin/options*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/options')); ?>",
                tags: ['0']
              },
              {
                text: 'Ерөнхийлөгчид',
                icon: 'fa fa-user-secret',
                state: {
                        selected:<?php echo e(Request::is('admin/president*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/presidents')); ?>",
                tags: ['0']
              },
              {
                text: 'И-мэйл илгээх',
                icon: 'fa fa-envelope-o',
                state: {
                        selected:<?php echo e(Request::is('admin/sendmail*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/sendmail')); ?>",
                tags: ['0']
              },
            ]
          },
              {
            text: 'Бидний тухай',
            selectable: false,
            state: {
                expanded: <?php echo e(Request::is('admin/vow*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/rule*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/sector*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/intro*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/history*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/structure*') ? 'true' : 'false'); ?>,
            },
             nodes: [
              {
                text: 'Танилцуулга',
                icon: 'fa fa-pencil-square-o',
                state: {
                    selected:<?php echo e(Request::is('admin/intro*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/intro')); ?>",
                tags: ['0']
              },
              {
                text: 'Түүх',
                icon: 'fa fa-history',
                state: {
                    selected:<?php echo e(Request::is('admin/history*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/history')); ?>",
                tags: ['0']
              },
               {
                text: 'Андгай',
                icon: 'fa fa-address-book',
                state: {
                    selected:<?php echo e(Request::is('admin/vow*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/vow')); ?>",
                tags: ['0']
              },
              {
                text: 'Дүрэм',
                icon: 'fa fa-book',
                state: {
                    selected:<?php echo e(Request::is('admin/rule*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/rule')); ?>",
                tags: ['0']
              },
              {
                text: 'Бүтэц',
                state: {
                    selected:<?php echo e(Request::is('admin/structure*') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-pie-chart',
                href: "<?php echo e(url('admin/structure')); ?>",
                tags: ['0']
              },
               {
                text: 'Салбаруудын мэдээлэл',
                state: {
                    selected:<?php echo e(Request::is('admin/sector*') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-question',
                href: "<?php echo e(url('admin/sector')); ?>",
                tags: ['0']
              },
            ]
          },
              {
            text: 'Хөтөлбөр',
            selectable: false,
            state: {
                expanded: <?php echo e(Request::is('admin/program*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/programname*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/programs*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/programcomment*') ? 'true' : 'false'); ?>,
            },
             nodes: [
              {
                text: 'Хөтөлбөрийн ангилал',
                state: {
                    selected:<?php echo e(Request::is('admin/programname*') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-list',
                href: "<?php echo e(url('admin/programname')); ?>",
                tags: ['0']
              },
              {
                text: 'Хөтөлбөр',
                state: {
                    selected:<?php echo e(Request::is('admin/programs*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/program') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-tasks',
                href: "<?php echo e(url('admin/programs')); ?>",
                tags: ['0']
              },
              {
                text: 'Хөтөлбөрийн сэтгэгдэл',
                state: {
                    selected:<?php echo e(Request::is('admin/programcomment*') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-comment',
                href: "<?php echo e(url('admin/programcomment')); ?>",
                tags: ['0']
              },
            ]
          },
          {
            text: 'Мэдээ',
            selectable: false,
            state: {
                expanded:  <?php echo e(Request::is('admin/news*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/category*') ? 'true' : 'false'); ?>,
            },
            nodes: [
              {
                text: 'Мэдээ',
                icon: 'fa fa-newspaper-o',
                state: {
                    selected:<?php echo e(Request::is('admin') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/news*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin')); ?>",
                tags: ['0']
              },
              {
                text: 'Мэдээний ангилал',
                state: {
                    selected:<?php echo e(Request::is('admin/category*') ? 'true' : 'false'); ?>

                },
                icon: 'fa fa-list',
                href: "<?php echo e(url('admin/category')); ?>",
                tags: ['0']
              },
            ]
          },
            {
            text: 'Холбогдох',
            selectable: false,
            state: {
                expanded: <?php echo e(Request::is('admin/location*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/faq*') ? 'true' : 'false'); ?> || <?php echo e(Request::is('admin/contacts*') ? 'true' : 'false'); ?>,
            },
             nodes: [
                  {
                text: 'Салбаруудын байрлал',
                icon: 'fa fa-map-marker',
                state: {
                    selected:<?php echo e(Request::is('admin/location*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/location')); ?>",
                tags: ['0']
              },
                {
                text: 'Санал хүсэлтүүд',
                icon: 'fa fa-archive',
                state: {
                    selected:<?php echo e(Request::is('admin/contacts*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/contacts')); ?>",
                tags: ['0']
              },
              {
                text: 'Түгээмэл асуулт хариултууд',
                icon: 'fa fa-question',
                state: {
                    selected:<?php echo e(Request::is('admin/faq*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/faq')); ?>",
                tags: ['0']
              },
            ]
          },
          {
                text: 'Хэрэглэгчид',
                state: {
                        selected:<?php echo e(Request::is('admin/users*') ? 'true' : 'false'); ?>

                },
                href: "<?php echo e(url('admin/users')); ?>",
                tags: ['0']
           },
        ];
        $('#treeview2').treeview({
          levels: 1,
          data: defaultData,
          enableLinks : true,
          showBorder: false,
        });
     
    </script>
    <?php $__env->stopPush(); ?>