<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
              <div class="card">
                    <div class="header">
                        <h4 class="title">Мэдээ засах</h4>
                    </div>
                    <div class="content">
                       <form method="POST" id="myform" action="<?php echo e(url('/admin/location/edit',$Location->id)); ?>">
                                   <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Аймаг/Дүүрэг нэр:</label>
                                                  <select class="form-control" id="location" required name='name'>
                                                        <option value="">Аймаг/Дүүрэг нэр</option>
                                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($province->id); ?>" <?php echo e($Location->province_id == $province->id ? 'selected' : ''); ?>><?php echo e($province->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </select>
                                            </div>
                                        </div>
                                    </div>
                                  
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <label>Холбогдох хүний нэр:</label>
                                                <input type="text" required class="form-control border-input" name='cpersonname' value="<?php echo e($Location->c_person_name); ?>" placeholder="Холбогдох хүний нэр">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <label>Холбогдох хүний дугаар:</label>
                                                <input type="text" required class="form-control border-input" name='cpersonphone' value="<?php echo e($Location->c_person_phone); ?>" placeholder="Холбогдох хүний дугаар">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <label>Холбогдох хүний и-мэйл:</label>
                                                <input type="email" class="form-control border-input" required name='cpersonemail' value="<?php echo e($Location->c_person_email); ?>" placeholder="Холбогдох хүний и-мэйл">
                                            </div>
                                        </div>
                                    </div>

                                      <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <label>Facebook хаяг:</label>
                                                <input type="text" class="form-control border-input"  name='cpersonfacebook' placeholder="Facebook хаяг" value="<?php echo e($Location->c_person_facebook); ?>">
                                            </div>
                                        </div>
                                    </div>

                                     <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                 <label>Нэмэлт мэдээлэл:</label>
                                                <textarea rows="5" class="form-control border-input"  name='information' placeholder="Нэмэлт мэдээлэл"><?php echo e($Location->information); ?></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Засах</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
	<script type="text/javascript">
        $('#lfm').filemanager('image');
    	$(document).ready(function(){

            $( "#myform" ).submit(function( event ) {
                $("body").loading();
            });

            <?php if(session('status')): ?>
            $("body").loading('stop');
        	$.notify({
            	icon: 'fa fa-check',
            	message: " <?php echo e(session('status')); ?>"

            },{
                type: 'success',
                timer: 2000
            });
           <?php endif; ?>
    	});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>