<?php echo $__env->make('partials.navbarNoTrans', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="section section-contact-us">
        <div class="contact-container">
            <div class="map">
                <div class="google-map big-map" style="height: 640px">
                </div>
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="locations" data-lat="<?php echo e($location->latitude); ?>" data-lng="<?php echo e($location->longitude); ?>" data-cname="<?php echo e($location->c_person_name); ?>" data-cemail="<?php echo e($location->c_person_email); ?>" data-cphone="<?php echo e($location->c_person_phone); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="section section-contact-form">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-4 col-md-offset-1 text-left">
                                <div class="contact-form">
                                    <div class="title-area">
                                        <h2>Захидал илгээх</h2>
                                    </div>
                                    <form action="<?php echo e(url('/contact')); ?>" id="contact-form" method="POST" data-toggle="validator">
                                        <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Таны цахим шуудан:</label>
                                                    <input type="email"  name="email" value="" required placeholder="Цахим шуудангийн хаягаа оруулана уу" class="form-control form-control-warning form-control-plain">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Таны илгээх захидал:</label>
                                                    <textarea name="message" required class="form-control form-control-plain" placeholder="Та бидэнд илгээх захидалаа бичнэ үү" rows="8"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Илгээх салбар сонгох</label>
                                                    <select class="form-control" name="location" required>
                                                            <option value="">Та МЗХ-ны салбараас сонгоно уу</option>
                                                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Таны утас:</label>
                                                    <input required type="text" name="phone" value="" placeholder="Та холбоо барих утасны дугаараа оруулана уу" class="form-control form-control-plain">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="col-md-6"></div>
                                                <div class="col-md-6 text-right" style="padding: 0">
                                                    <button type="submit" class="btn btn-dark">
                                                              Contact Us
                                                              <i class="fa fa-paper-plane"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-4 col-md-offset-1">
                                <div class="contact-form">
                                    <div class="title-area">
                                        <h2>Түгээмэл асуулт хариултууд</h2>
                                    </div>
                                        <div class="row">
                                            <div class="col-md-12 text-left">
                                                <div class="panel-group" id="accordion">
                                                    <?php if($faqs->isEmpty()): ?>
                                                        <p>Түгээмэл асуулт хариулт байхгүй байна.</p>
                                                    <?php else: ?>
                                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h2 class="panel-title">
                                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($faq->id); ?>"><?php echo e($faq->question); ?></a>
                                                            </h2>
                                                        </div>
                                                        <div id="collapse<?php echo e($faq->id); ?>" class="panel-collapse collapse <?php if($index == 0): ?> <?php echo e('in'); ?> <?php endif; ?>">
                                                            <div class="panel-body">
                                                                <p><?php echo e($faq->answer); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->startPush('script'); ?>
   <script type="text/javascript">

        $('#contact-form').bootstrapValidator({
            fields: {
                phone: {
                    validators: {
                        notEmpty: {
                            message: 'Талбарын утгыг бөглөнө үү'
                        }
                    }
                },
                email: {
                    validators: {
                        notEmpty: {
                            message: '* Талбарын утгыг бөглөнө үү'
                        },
                        emailAddress: {
                            message: '* И-мэйл хаяг биш байна.'
                        }
                    }
                },
                location: {
                    validators: {
                        notEmpty: {
                            message: '* Талбарын утгыг бөглөнө үү'
                        }
                    }
                },
                message: {
                    validators: {
                        notEmpty: {
                            message: '* Талбарын утгыг бөглөнө үү'
                        },
                        stringLength: {
                            max: 500,
                            message: '* Их тэмдэгт оруулсан байна.'
                        }
                    }
                }
            }
        });
            <?php if(session('contactstatus')): ?>
        	$.notify({
            	icon: 'fa fa-check',
            	message: " <?php echo e(session('contactstatus')); ?>"

            },{
                type: 'success',
                timer: 1000
            });
           <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>