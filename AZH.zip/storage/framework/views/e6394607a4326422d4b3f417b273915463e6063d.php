<?php $__env->startSection('content'); ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Бүтэц</h4>
                            </div>
                             <div class="content">
                                <form method="POST" id="myform" action="<?php echo e(url('/admin/structure')); ?>">
                                    <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Контент</label>
                                                <textarea rows="15"  class="form-control my-editor border-input" name="description" placeholder="Контентоо оруулна уу..."><?php if(!$structure->isEmpty()): ?><?php echo e($structure[0]->description); ?><?php endif; ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="text-center">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd">Оруулах</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
	<script type="text/javascript">
    	$(document).ready(function(){
             $('#myform').validator().on('submit', function (e) {
                if (!e.isDefaultPrevented()) {
                    $("body").loading();
                }
            })
            <?php if(session('structurestatus')): ?>
            $("body").loading('stop');
        	$.notify({
            	icon: 'fa fa-check',
            	message: " <?php echo e(session('structurestatus')); ?>"

            },{
                type: 'success',
                timer: 1000
            });
           <?php endif; ?>
    	});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>