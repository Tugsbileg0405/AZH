<div class="container">
    <div class="section section-signin">
        <div class="form-container">
            <div class="col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1 text-center">
                <div class="title-area">
                    <h2>АЗХ админ</h2>
                    <div class="separator separator-danger">✻</div>
                </div>
                 <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                         <?php echo e(csrf_field()); ?>

                        <label><h4 class="text-gray">Таны и-мэйл хаяг:</h4></label>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="MichaelJordan@gmail.com" class="form-control form-control-plain">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span> 
                             <?php endif; ?>
                        </div>

                        <label><h4 class="text-gray">Таны нууц үг: </h4></label>
                        <div  class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <input id="password" type="password" name="password" required placeholder="●●●●" class="form-control form-control-plain">
                             <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span> 
                             <?php endif; ?>
                        </div>

                        <div class="footer">
                            <button type="submit" class="btn btn-blue btn-round btn-fill btn-wd">
                                        Нэвтрэх
                            </button>
                        </div>
                 </form>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>