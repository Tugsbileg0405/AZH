<?php echo $__env->make('partials.navbarHome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="section section-header">
    <div class="parallax">
        <div id="headerCarousel" class="carousel slide" data-interval="false" data-ride="carousel">
            <div class="carousel-inner">
                <?php if(!$slides->isEmpty()): ?> <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="<?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?> item">
                    <div class="parallax ">
                        <div class="image" style="background-image: url('<?php echo e(asset($slide->image)); ?>')">
                        </div>
                        <div class="container">
                            <div class="content">
                                <div class="title-area">
                                    <h2 class="title-modern"><?php echo e($slide->title); ?></h2>
                                    <p class="description"><?php echo e($slide->description); ?></p>
                                </div>
                                <?php if(!$slide->isButton == 0): ?>
                                <div class="button-get-started">
                                    <a class="btn btn-white" href="<?php echo e($slide->btnLink); ?>" target="_blank">
                                                <?php echo e($slide->btnText); ?>

                                                <i class="fa fa-chevron-right"></i>
                                            </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
            </div>
            <div id="carousel-wrapper">
                <a class="left carousel-control" href="#headerCarousel" role="button" data-slide="prev">
                    <span class="fa fa-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#headerCarousel" role="button" data-slide="next">
                    <span class="fa fa-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
<hr class="transition-timer-carousel-progress-bar" />
<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="row">
                    <div class="col-md-4">
                        <div class="info-icon">
                            <h1>31</h1>
                            <p class="description">Салбар</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-icon">
                            <h1>5000+</h1>
                            <p class="description">Гишүүн</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="info-icon">
                            <h1>1200+</h1>
                            <p class="description">Хөтөлбөр</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if(!$ProgramNames->isEmpty()): ?>
<div class="section section-news">
    <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="false">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="row">
                        <div class="col-md-8 col-sm-8">
                            <p class="slider-subtitle">ҮЙЛ АЖИЛЛАГААНЫ ЧИГЛЭЛҮҮД</p>
                            <ol class="carousel-indicators">
                                <?php $__currentLoopData = $ProgramNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ProgramName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-target="#myCarousel" data-slide-to="<?php echo e($index); ?>" class="<?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?>"></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-inner" role="listbox">
            <?php $programs = app('App\Program'); ?> 
            <?php $comments = app('App\Programcomment'); ?> 
            <?php $__currentLoopData = $ProgramNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ProgramName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item <?php if($index == 0): ?> <?php echo e('active'); ?> <?php endif; ?>">
                <div class="container carousel-contain">
                    <div class="absolute-class">
                         <img src="<?php echo e(asset('img/logo/rectangle-6.png')); ?>" class="section-news-img">
                    </div>
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <a href="<?php echo e(url('programs', $ProgramName->id)); ?>">
                                         <p class="slider-title"><?php echo e($ProgramName->name); ?></p>
                                    </a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8 col-sm-8">
                                    <div class="row">
                                        <?php $__currentLoopData = $programs->where('ProgramName_id',$ProgramName->id)->orderBy('created_at', 'desc')->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(url('program', $program->id)); ?>">
                                                 <div class="col-xs-6  col-md-4 col-sm-4">
                                                    <div class="card info-section">
                                                        <img class="card-img" src="<?php echo e(asset($program->image)); ?>" alt="Card image">
                                                        <div class="content">
                                                            <p class="card-text"><?php echo e($program->title); ?></p>
                                                        </div>
                                                    </div>
                                                 </div>
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <p class="slider-comment">Хөтөлбөрийн талаарх сэтгэгдлүүд</p>
                                </div>
                                <div class="col-md-12 col-sm-12" id="comment">
                                    <div class="row">
                                         <?php $__currentLoopData = $comments->where('program_id',$ProgramName->id)->orderBy('created_at', 'desc')->take(1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <div class="col-md-8 col-sm-8" id="comments">
                                            <div class="media">
                                                <a class="pull-left" href="#">
                                                    <img class="media-object" src="<?php echo e(asset($comment->imageURL)); ?>" alt="Media Object">
                                                </a>
                                                <div class="media-body">
                                                    <h4 class="media-heading"><?php echo e($comment->title); ?></h4>
                                                    <p><?php echo e($comment->subtitle); ?></p>
                                                    <span><?php echo e($comment->description); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(url('programs')); ?>">
                                        <button class="btn btn-showinfo">
                                                Хөтөлбөрүүдийг харах
                                                <i class="fa fa-chevron-right"></i>
                                        </button>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="fa fa-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="fa fa-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<?php endif; ?>




<div class="section section-our-team-freebie">
    <div class="container">
        <div class="content">
            <div class="row">
                <div class="title-area">
                    <h2 class="description">Мэдээ мэдээлэл</h2>
                </div>
            </div>

            <div class="team">
                <div class="row">
                    <div class=" col-md-10 col-md-offset-1">
                        <div class="row">
                            <?php $__currentLoopData = $latestnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12  col-md-4 col-sm-4">
                                <div class="card">
                                    <a href="<?php echo e(url('news', $news->id)); ?>">
                                        <img class="card-img-top" src="<?php echo e(asset($news->image)); ?>">
                                        </a>
                                    <div class="card-block">
                                        <h4 class="card-title"><?php echo e($news->created_at->format('Y оны m сарын d өдөр')); ?></h4>
                                        <p class="card-text"><?php echo e($news->title); ?></p>
                                    </div>
                                    <a href="<?php echo e(url('news', $news->id)); ?>">
                                        <button class="btn btn-simple">
                                            Дэлгэрэнгүй унших
                                            <i class="fa fa-chevron-right"></i>
                                       </button>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="title-area">
                    <a href="<?php echo e(url('news')); ?>">
                        <button class="btn btn-showmore">Мэдээллүүдийг харах<i class="fa fa-chevron-right"></i></button>
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="section section-our-clients-freebie">
    <div class="container">
        <div class="title-area">
            <h2 class="description">Ерөнхийлөгчид</h2>
        </div>
        <ul class="nav nav-text" id="myTab" role="tablist">
            <?php $__currentLoopData = $presidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $president): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="<?php if($loop->last): ?> <?php echo e('active'); ?> <?php endif; ?>">
                <a href="#testimonial<?php echo e($president->id); ?>" role="tab" data-toggle="tab">
                    <div class="image-clients">
                        <img alt="..." src="<?php echo e(asset($president->photo_URL)); ?>" />
                        <p class="pre-firstname"><?php echo e($president->lastname); ?></p>
                        <p class="pre-lastname"><?php echo e($president->firstname); ?></p>
                    </div>
                </a>
                <div class="president-timeline">
                    <span class="tl-round"></span>
                    <p><?php echo e($president->year); ?></p>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="tab-content">
            <?php $__currentLoopData = $presidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $president): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tab-pane <?php if($loop->last): ?> <?php echo e('active'); ?> <?php endif; ?>" id="testimonial<?php echo e($president->id); ?>">
                <p class="description ">
                    <?php echo e($president->description); ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="section footer-logo">
    <div class="container">
        <div class="row">
            <div class=" col-md-4 col-md-offset-4 ">
                <div class="text-xs-center text-lg-center">
                    <img src="<?php echo e(asset('img/logo/bitmap_2.png')); ?>" class="img-responsive center-block">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section ">
    <div class="container ">
        <div class="row ">
            <div class="col-md-6 col-sm-8 col-xs-12 col-md-offset-3 col-sm-offset-2">
                <button class="btn btn-follow ">
                        Биднийг дагаарай
                        <i class="fa fa-chevron-right "></i>
                    </button>
                <button class="btn-like ">
                        <i class="fa fa-thumbs-up "></i>
                        Like
                    </button>
                <button class="btn-twitter ">
                        <i class="fa fa-twitter "></i>
                        Follow @TwitterDev
                    </button>
            </div>
        </div>
    </div>
</div>

<input type="text" hidden id="number" value="<?php echo e($ProgramNames->count()); ?>">
<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startPush('script'); ?>
    <script>

        //     var slider = [];
        //     var length = $('#number').val();
        //     var i = 0; 
        //     if(length > 0){
        //          for(i; i< length;i++){
        //            slider.push($('#responsive' + i ).lightSlider({
        //                     item: 3,
        //                     loop: false,
        //                     slideMove: 2,
        //                     easing: 'cubic-bezier(0.25, 0, 0.25, 1)',
        //                     speed: 600,
        //                     responsive: [{
        //                             breakpoint: 800,
        //                             settings: {
        //                                 item: 3,
        //                                 slideMove: 1,
        //                                 slideMargin: 6,
        //                             }
        //                         },
        //                         {
        //                             breakpoint: 480,
        //                             settings: {
        //                                 item: 2,
        //                                 slideMove: 1
        //                             }
        //                         }
        //                     ]
        //             }));
        //         }
        //     }

        //   $('#myCarousel').on('slide.bs.carousel', function (e) {
        //         var active = $(e.target).find('.carousel-inner > .item.active');
        //         var from = active.index();
        //         var next = $(e.relatedTarget);
        //         var to = next.index();
        //         slider[from].refresh();
        //     })
            
          
            <?php if(session('substatus')): ?>
        	$.notify({
            	icon: 'fa fa-check',
            	message: " <?php echo e(session('substatus')); ?>"

            },{
                type: 'success',
                timer: 2000
            });
           <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>