 <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> он <a href="http://www.alchemist.mn">Alchemist Technology</a>
                </div>
            </div>
        </footer>