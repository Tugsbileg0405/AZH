<html>

<head>
    <style>
        .column {
            float: left;
            width: 50%;
        }
    </style>
</head>

<body>
    <div class="column">
        <h2>{{ $title }}</h2>
        <p>{!! $description !!}</p> 
    </div>
</body>

</html>