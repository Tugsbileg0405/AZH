<html>

<head>
    <style>
        .column {
            float: left;
            width: 50%;
        }
    </style>
</head>

<body>
    <div class="column">
        {{$email}} хэрэглэгч манай веб хуудсыг дагасанд баярлалаа.       
    </div>
</body>

</html>