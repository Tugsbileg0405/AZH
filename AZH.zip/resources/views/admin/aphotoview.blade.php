<div class="photo">
	<img src="{{ asset($photo) }}">
	<input type="hidden" name="photo" value="{{ $photo }}">
	<i class="fa fa-close fa-4x" aria-hidden="true"></i>
    <div class="wait">
        <div class="loader"></div>
    </div>
</div>