﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","eo",{button:"Enmeti kodaĵeron",codeContents:"Kodenhavo",emptySnippetError:"Kodaĵero ne povas esti malplena.",language:"Lingvo",title:"Kodaĵero",pathName:"kodaĵero"});